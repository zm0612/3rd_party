Deep Neural Network module
==========================