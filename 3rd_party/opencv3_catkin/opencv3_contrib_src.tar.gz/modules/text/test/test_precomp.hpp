#ifndef __OPENCV_TEST_TEXT_PRECOMP_HPP__
#define __OPENCV_TEST_TEXT_PRECOMP_HPP__

#include "opencv2/core.hpp"
#include "opencv2/ts.hpp"
#include "opencv2/text.hpp"

#endif
