#include "test_precomp.hpp"

CV_TEST_MAIN("",
    cvtest::addDataSearchSubDirectory("contrib"),
    cvtest::addDataSearchSubDirectory("contrib/text")
)
